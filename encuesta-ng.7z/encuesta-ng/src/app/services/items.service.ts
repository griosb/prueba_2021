import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { marcaFavorita } from '../interface/MarcaFavorita';
import { Api } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ItemsService {

  readonly apiUrl: string;
  endpoint = "items"

  constructor(private http: HttpClient) {
    this.apiUrl = Api.api;
  }


  getAll(): Observable<marcaFavorita> {
    return this.http.get<marcaFavorita>(`${this.apiUrl}${this.endpoint}`)
  }


}

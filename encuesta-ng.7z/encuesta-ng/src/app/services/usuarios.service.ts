import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { Api } from '../../environments/environment';
import { usuario } from '../interface/Usuario';

@Injectable({
  providedIn: 'root'
})
export class UsuariosService {
  readonly apiUrl: string;
  endpoint = "login"

  constructor(private http: HttpClient) {
    this.apiUrl = Api.api;
  }

  loginServices(body: any) {
    return this.http.post(`${this.apiUrl}${this.endpoint}`, body)

  }
}

import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { usuario } from '../interface/Usuario';
import { Api } from '../../environments/environment';
import { encuesta } from '../interface/Encuesta';

@Injectable({
  providedIn: 'root'
})
export class EncuestaService {
  readonly apiUrl: string;
  endpoint = "encuestas"
  constructor(private http: HttpClient) {
    this.apiUrl = Api.api;
  }


  getAll(): Observable<encuesta> {
    return this.http.get<encuesta>(`${this.apiUrl}${this.endpoint}`)
  }

  eliminarEncuesta(id: any, body: any) {
    return this.http.patch(`${this.apiUrl}${this.endpoint}/${id}`, body)
  }

  guardarEncuesta(body: any): Observable<encuesta> {
    return this.http.post<encuesta>(`${this.apiUrl}${this.endpoint}`, body)
  }
}


import { Component, OnInit } from '@angular/core';
import { EncuestaService } from 'src/app/services/encuesta.service';


@Component({
  selector: 'app-consulta',
  templateUrl: './consulta.component.html',
  styleUrls: ['./consulta.component.scss']
})
export class ConsultaComponent implements OnInit {

  constructor(public encuestaService: EncuestaService) { }

  ngOnInit(): void {
    this.getAllEncuestas()
  }
  displayedColumns: string[] = ['posicion', 'numeroDoc', 'email', 'comentario', 'marcafavorita', 'fecharespuesta', 'accion'];
  dataSource: any;

  getAllEncuestas() {
    let aux: any
    this.encuestaService.getAll().subscribe(r => {

      aux = r
      this.dataSource = aux.filter((r: any) => { return r.borrado == false })

      console.log(this.dataSource)

    });



  }

  deleteEncuesta(id: number, data: any) {
    console.log(id)
    data.borrado = true
    this.encuestaService.eliminarEncuesta(id, data).subscribe(r => {
      this.getAllEncuestas()

    })
  }
}

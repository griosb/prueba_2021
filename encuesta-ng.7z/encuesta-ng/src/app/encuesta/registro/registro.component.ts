import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EncuestaService } from 'src/app/services/encuesta.service';
import { ItemsService } from 'src/app/services/items.service';
import { encuesta } from '../../interface/Encuesta';
@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.scss']
})
export class RegistroComponent implements OnInit {
  listmarcasfavoritas: any

  form = new FormGroup({
    id: new FormControl(0),
    num_documento: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required]),
    marca_favorita: new FormControl('', [Validators.required]),
    comentario: new FormControl('', [Validators.required]),
  });
  constructor(public itemService: ItemsService, public encuestaService: EncuestaService, private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.getMarca();
  }


  getMarca() {
    this.itemService.getAll().subscribe(r => {

      this.listmarcasfavoritas = r;

    })
  }
  onSubmit() {
    let encuesta: encuesta = this.form.value
    encuesta.usuario_creacion = "geo";
    encuesta.borrado = false
    encuesta.estado = 0
    var today = new Date();


    encuesta.fechaRegistroDate = today
    console.log(today)
    this.encuestaService.guardarEncuesta(encuesta).subscribe(r => {
      console.log(r)
    })
    this.router.navigate(['/home']);
  }
}

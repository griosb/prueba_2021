import { marcaFavorita } from "./MarcaFavorita";
import { usuario } from "./Usuario";

export interface encuesta {
    id?: number,
    num_documento: number,
    email: string,
    comentario?: string,
    marca_favorita?: marcaFavorita
    fechaRegistroDate?: Date,
    fechaModificacion?: Date,
    estado?: number,
    borrado?: boolean,
    usuario_creacion?: string
}


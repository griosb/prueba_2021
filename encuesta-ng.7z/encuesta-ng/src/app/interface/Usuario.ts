export interface usuario {
    id?: number,
    nombre_usuario?: string,
    password?: number,
    intentos?: number,
    estado?: boolean,
    borrado?: boolean,
}

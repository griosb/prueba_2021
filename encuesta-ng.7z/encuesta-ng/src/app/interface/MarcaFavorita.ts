export interface marcaFavorita {
    id: number,
    codigo: string,
    descripcion?: string,
    estado: boolean,
    borrado: boolean,
    nombre_item: string,
}

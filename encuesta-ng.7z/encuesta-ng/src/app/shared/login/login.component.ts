import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UsuariosService } from 'src/app/services/usuarios.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  hide = true;
  intento = 0;

  form = new FormGroup({
    nombre_usuario: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),

  });

  constructor(private route: ActivatedRoute,
    private router: Router, private userService: UsuariosService) { }

  ngOnInit(): void {
  }


  login() {
    let data = this.form.value

    // console.log(data)
    this.userService.loginServices(data).subscribe(r => {
      if (r != null) {
        localStorage.setItem("token", JSON.stringify(r))
        console.log(r)
        this.router.navigate(['/home']);
      } else {
        this.intento = this.intento + 1
        alert(`Usuario Incorrecto lleva ${this.intento} intentos`)
        this.form = new FormGroup({
          nombre_usuario: new FormControl('', [Validators.required]),
          password: new FormControl('', [Validators.required]),

        });
        if (this.intento == 3) {
          alert("El usuario ha sido bloqueado")
        }
      }
    })




  }
}

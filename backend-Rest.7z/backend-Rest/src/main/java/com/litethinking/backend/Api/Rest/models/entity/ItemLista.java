package com.litethinking.backend.Api.Rest.models.entity;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.ForeignKey;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@Table(name = "item_lista")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class ItemLista {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
    
    @JoinColumn(name = "id_item", referencedColumnName = "id", foreignKey = @ForeignKey(name = "FK_ID_ITEM"), nullable = false)
    @ManyToOne(fetch = FetchType.EAGER)
	private Item id_item;
		
	private String codigo;
	private String nombre_lista;
	private String descripcion;
	private Boolean estado;
	private Boolean borrado;

	public Integer getId() {
		return id;
	}

	public Item getId_item() {
		return id_item;
	}

	public void setId_item(Item id_item) {
		this.id_item = id_item;
	}

	public String getNombre_lista() {
		return nombre_lista;
	}

	public void setNombre_lista(String nombre_lista) {
		this.nombre_lista = nombre_lista;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombre_item() {
		return nombre_lista;
	}

	public void setNombre_item(String nombre_item) {
		this.nombre_lista = nombre_item;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Boolean getEstado() {
		return estado;
	}

	public void setEstado(Boolean estado) {
		this.estado = estado;
	}

	public Boolean getBorrado() {
		return borrado;
	}

	public void setBorrado(Boolean borrado) {
		this.borrado = borrado;
	}

}

package com.litethinking.backend.Api.Rest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.litethinking.backend.Api.Rest.controller.UsuarioRepository;
import com.litethinking.backend.Api.Rest.models.entity.Usuario;

@Service
public class UsuarioService {

	@Autowired
	private UsuarioRepository usuarioRepository;

	public Usuario login(Usuario usuario) {
		String nombre_usuario = usuario.getNombre_usuario();
		String password = usuario.getPassword();
		System.out.println("desde el service'" + nombre_usuario + "'");
		// usuarioRepository.findByNombre_usuario(nombre_usuario);
		return usuarioRepository.findUsuario(nombre_usuario,password);
	
	}

}

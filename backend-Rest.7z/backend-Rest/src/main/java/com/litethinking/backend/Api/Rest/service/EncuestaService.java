package com.litethinking.backend.Api.Rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.litethinking.backend.Api.Rest.controller.EncuestaRepository;
import com.litethinking.backend.Api.Rest.controller.ItemRepository;
import com.litethinking.backend.Api.Rest.models.entity.Encuesta;

import com.litethinking.backend.Api.Rest.models.entity.ItemLista;

@Service
public class EncuestaService {

	@Autowired
	private EncuestaRepository encuestaRepository;

	@Autowired
	private ItemRepository itemRepository;

	public List<ItemLista> obtItems() {
		return itemRepository.findAll();

	}

	public List<Encuesta> obtEncuestas() {
		return encuestaRepository.findAll();
	}

	public void guardarEncuesta(Encuesta encuesta) {
		encuestaRepository.save(encuesta);
	}

	public void eliminarEncuesta(Encuesta encuesta) {
		encuestaRepository.save(encuesta);
	}
	
	public Optional<Encuesta> obtenerEncuesta(Integer id){
	 
	 return encuestaRepository.findById(id);		
	}

}

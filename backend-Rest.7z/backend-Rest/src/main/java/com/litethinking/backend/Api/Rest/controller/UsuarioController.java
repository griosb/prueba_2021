package com.litethinking.backend.Api.Rest.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;


import com.litethinking.backend.Api.Rest.models.entity.Usuario;
import com.litethinking.backend.Api.Rest.service.UsuarioService;


@RestController
@RequestMapping("/api")
public class UsuarioController {

	@Autowired
	private UsuarioService usuarioService;

	
	@PostMapping("/login")
	public Usuario login(@RequestBody Usuario usuario) {
		 
		return usuarioService.login(usuario);
				
		
	}
}

package com.litethinking.backend.Api.Rest;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class BackendRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendRestApplication.class, args);
	}

}

package com.litethinking.backend.Api.Rest.controller;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import org.springframework.stereotype.Repository;

import com.litethinking.backend.Api.Rest.models.entity.Usuario;



@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer>{
 
		@Query("SELECT us FROM Usuario us WHERE us.nombre_usuario=?1 and us.password=?2")
		public Usuario findUsuario(String nombre_usuario,String password);
}

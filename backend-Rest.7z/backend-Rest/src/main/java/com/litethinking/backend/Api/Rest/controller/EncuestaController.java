package com.litethinking.backend.Api.Rest.controller;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.litethinking.backend.Api.Rest.models.entity.Encuesta;

import com.litethinking.backend.Api.Rest.models.entity.ItemLista;
import com.litethinking.backend.Api.Rest.service.EncuestaService;

@RestController
@RequestMapping("/api")
public class EncuestaController {

	
	@Autowired
	private EncuestaService encuestaService;

	@GetMapping("/items")
	public List<ItemLista> obternerItems() {
		return encuestaService.obtItems();

	}

	@GetMapping("/encuestas")
	public List<Encuesta> obtenerEncuestas() {

		return encuestaService.obtEncuestas();

	}

	@PostMapping("/encuestas")
	public Encuesta guardarEncuesta(@RequestBody Encuesta encuesta) {
		encuestaService.guardarEncuesta(encuesta);
		return encuesta;
	}

	@PatchMapping("/encuestas/{id}")
	public ResponseEntity<?>  eliminarEncuesta(@PathVariable Integer id, @RequestBody Encuesta encuesta) {
		
		Optional<Encuesta> encuesta2 = encuestaService.obtenerEncuesta(id);
		if(encuesta2.isPresent()) {
			encuestaService.guardarEncuesta(encuesta);
			return ResponseEntity.ok(encuesta);
		}else {
			return ResponseEntity.notFound().build();
		}
		
	}

}

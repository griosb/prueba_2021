package com.litethinking.backend.Api.Rest.models.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "encuesta")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Encuesta {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private Integer num_documento;
	private String email;
	private String comentario;
	
	@JoinColumn(name = "marca_favorita", referencedColumnName = "id", foreignKey = @ForeignKey(name = "FK_MARCAFAVORITA"), nullable = false)
	@ManyToOne(fetch = FetchType.EAGER)
	private ItemLista marca_favorita;

	public ItemLista getMarca_favorita() {
		return marca_favorita;
	}

	public void setMarca_favorita(ItemLista marca_favorita) {
		this.marca_favorita = marca_favorita;
	}

	@Column(name = "fecha_creacion",columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaRegistroDate;

	@Column(name = "fecha_modificacion")
	@Temporal(TemporalType.DATE)
	private Date fechaModificacion;
	
	private Integer estado;
	private Boolean borrado;

	//@JoinColumn(name = "usuario_creacion", referencedColumnName = "id", foreignKey = @ForeignKey(name = "FK_ID_USUARIO"), nullable = false)
	//@ManyToOne(fetch = FetchType.EAGER)

	private String usuario_creacion;
	// private Integer usuario_creacion;

	public void setUsuario_creacion(String usuario_creacion) {
		this.usuario_creacion = usuario_creacion;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getNum_documento() {
		return num_documento;
	}

	public void setNum_documento(Integer num_documento) {
		this.num_documento = num_documento;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public Date getFechaRegistroDate() {
		return fechaRegistroDate;
	}

	public void setFechaRegistroDate(Date fechaRegistroDate) {
		this.fechaRegistroDate = fechaRegistroDate;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public Boolean getBorrado() {
		return borrado;
	}

	public void setBorrado(Boolean borrado) {
		this.borrado = borrado;
	}

	

	public Integer getEstado() {
		return estado;
	}

	public void setEstado(Integer estado) {
		this.estado = estado;
	}

	public String getUsuario_creacion() {
		return usuario_creacion;
	}

	

}

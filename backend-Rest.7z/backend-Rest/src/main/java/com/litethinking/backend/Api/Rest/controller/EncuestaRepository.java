package com.litethinking.backend.Api.Rest.controller;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.litethinking.backend.Api.Rest.models.entity.Encuesta;

@Repository
public interface EncuestaRepository extends JpaRepository<Encuesta, Integer> {

	
	
}
